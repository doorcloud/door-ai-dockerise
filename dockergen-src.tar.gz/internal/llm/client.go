package llm

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"strings"

	"github.com/sashabaranov/go-openai"
)

// Client wraps the OpenAI client with our specific needs.
type Client struct {
	client *openai.Client
	logger *slog.Logger
}

// NewClient creates a new LLM client.
func NewClient(apiKey string) (*Client, error) {
	if apiKey == "" {
		return nil, fmt.Errorf("OPENAI_API_KEY is required")
	}

	client := openai.NewClient(apiKey)
	logger := slog.New(slog.NewTextHandler(os.Stderr, &slog.HandlerOptions{
		Level: slog.LevelDebug,
	}))

	return &Client{
		client: client,
		logger: logger,
	}, nil
}

// GenerateFacts prompts the LLM to extract facts from snippets.
func (c *Client) GenerateFacts(ctx context.Context, snippets []string) (map[string]interface{}, error) {
	prompt := buildFactsPrompt(snippets)

	if os.Getenv("DG_DEBUG") == "1" {
		c.logger.Debug("facts prompt", "content", prompt)
	}

	resp, err := c.client.CreateChatCompletion(
		ctx,
		openai.ChatCompletionRequest{
			Model: openai.GPT4,
			Messages: []openai.ChatCompletionMessage{
				{
					Role:    openai.ChatMessageRoleSystem,
					Content: prompt,
				},
			},
		},
	)
	if err != nil {
		return nil, fmt.Errorf("LLM completion failed: %w", err)
	}

	if os.Getenv("DG_DEBUG") == "1" {
		c.logger.Debug("facts response", "content", resp.Choices[0].Message.Content)
	}

	var facts map[string]interface{}
	if err := json.Unmarshal([]byte(resp.Choices[0].Message.Content), &facts); err != nil {
		return nil, fmt.Errorf("failed to parse LLM response: %w", err)
	}

	return facts, nil
}

// GenerateDockerfile creates a new Dockerfile based on the extracted facts.
func (c *Client) GenerateDockerfile(ctx context.Context, facts map[string]interface{}) (string, error) {
	prompt := buildDockerfilePrompt(facts)

	if os.Getenv("DG_DEBUG") == "1" {
		c.logger.Debug("dockerfile prompt", "content", prompt)
	}

	resp, err := c.client.CreateChatCompletion(
		ctx,
		openai.ChatCompletionRequest{
			Model: openai.GPT4,
			Messages: []openai.ChatCompletionMessage{
				{
					Role:    openai.ChatMessageRoleSystem,
					Content: prompt,
				},
			},
		},
	)
	if err != nil {
		return "", fmt.Errorf("LLM completion failed: %w", err)
	}

	if os.Getenv("DG_DEBUG") == "1" {
		c.logger.Debug("dockerfile response", "content", resp.Choices[0].Message.Content)
	}

	return strings.TrimSpace(resp.Choices[0].Message.Content), nil
}

// FixDockerfile attempts to fix a Dockerfile based on the build error.
func (c *Client) FixDockerfile(ctx context.Context, facts map[string]interface{}, dockerfile string, buildDir string, errorLog string, attempt int) (string, error) {
	prompt := fmt.Sprintf(`I need help fixing a Dockerfile. Here are the project facts:

%s

The current Dockerfile:
%s

Build directory: %s

Error log:
%s

Attempt %d/4. Please fix the Dockerfile. Focus on:
1. Correcting any syntax errors
2. Ensuring all required files are copied
3. Using the correct build context
4. Setting the right working directory

Return only the fixed Dockerfile, no explanations.`,
		formatFacts(facts),
		dockerfile,
		buildDir,
		errorLog,
		attempt,
	)

	resp, err := c.client.CreateChatCompletion(
		ctx,
		openai.ChatCompletionRequest{
			Model: openai.GPT4,
			Messages: []openai.ChatCompletionMessage{
				{
					Role:    openai.ChatMessageRoleSystem,
					Content: "You are a Docker expert. Fix Dockerfiles based on error logs.",
				},
				{
					Role:    openai.ChatMessageRoleUser,
					Content: prompt,
				},
			},
		},
	)
	if err != nil {
		return "", fmt.Errorf("create completion: %w", err)
	}

	if len(resp.Choices) == 0 {
		return "", fmt.Errorf("no completion choices")
	}

	return strings.TrimSpace(resp.Choices[0].Message.Content), nil
}

// formatFacts formats the facts map for the prompt.
func formatFacts(facts map[string]interface{}) string {
	var sb strings.Builder
	for k, v := range facts {
		sb.WriteString(fmt.Sprintf("%s: %v\n", k, v))
	}
	return sb.String()
}

func buildFactsPrompt(snippets []string) string {
	return fmt.Sprintf(`SYSTEM
You are a code analysis expert. Given a set of code snippets, extract key facts about the project.
The output must be valid JSON with the following structure:
{
  "language": "primary language",
  "framework": "web framework if any",
  "version": "framework version if known",
  "build_tool": "build system (maven, gradle, etc)",
  "build_cmd": "command to build",
  "artifact": "path to built artifact",
  "ports": [list of ports],
  "env": ["list of env vars"],
  "health": "health check endpoint if any",
  "dependencies": ["list of key deps"]
}

SNIPPETS:
%s`, strings.Join(snippets, "\n\n"))
}

func buildDockerfilePrompt(facts map[string]interface{}) string {
	factsJSON, _ := json.MarshalIndent(facts, "", "  ")
	return fmt.Sprintf(`SYSTEM
You are a senior DevOps engineer. Generate a Dockerfile for this project.
PROJECT_FACTS:
%s
TASK:
  • Produce a complete Dockerfile that builds and runs this project.
  • For Spring Boot 3.x, use JDK 17 or higher (e.g. eclipse-temurin:17-jdk).
  • If pom_path is provided, WORKDIR to that directory before running Maven.
  • Use ./mvnw wrapper if available, otherwise use maven:3.9-eclipse-temurin-17.
  • Start with "FROM " and include at least one RUN or COPY layer.
  • No explanations, no markdown, output Dockerfile ONLY.`, factsJSON)
}

func buildFixPrompt(facts map[string]interface{}, prevDockerfile string, errorLog string, attempt int) string {
	factsJSON, _ := json.MarshalIndent(facts, "", "  ")
	return fmt.Sprintf(`SYSTEM
You are a senior DevOps engineer. The previous Dockerfile failed (attempt %d/3).
PROJECT_FACTS:
%s
PREVIOUS_DOCKERFILE:
%s
BUILD_OR_RUN_ERROR:
%s
TASK:
  • Analyze why the build failed.
  • For Spring Boot 3.x, use JDK 17 or higher (e.g. eclipse-temurin:17-jdk).
  • If pom_path is provided, WORKDIR to that directory before running Maven.
  • Use ./mvnw wrapper if available, otherwise use maven:3.9-eclipse-temurin-17.
  • Produce a complete replacement Dockerfile that solves the problem.
  • Start with "FROM " and include at least one RUN or COPY layer.
  • No explanations, no markdown, output Dockerfile ONLY.`, attempt, factsJSON, prevDockerfile, errorLog)
}
