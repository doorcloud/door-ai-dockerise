package facts

import (
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strings"

	"github.com/yourorg/dockergen/internal/llm"
	"github.com/yourorg/dockergen/internal/util"
)

// Facts represents the extracted information about a project.
type Facts struct {
	// Language is the primary programming language (e.g., "java", "javascript").
	Language string `json:"language"`

	// Framework is the web framework (e.g., "spring-boot", "express").
	Framework string `json:"framework"`

	// Version is the framework version.
	Version string `json:"version"`

	// BuildTool is the build system (e.g., "maven", "npm").
	BuildTool string `json:"build_tool"`

	// BuildCmd is the command to build the project.
	BuildCmd string `json:"build_cmd"`

	// BuildDir is the directory containing the build manifest (e.g., pom.xml, package.json).
	BuildDir string `json:"build_dir"`

	// Artifact is the path to the built artifact.
	Artifact string `json:"artifact"`

	// Ports are the exposed ports.
	Ports []int `json:"ports"`

	// Env are environment variables.
	Env map[string]string `json:"env"`

	// Health is the health check endpoint.
	Health string `json:"health"`

	// Dependencies are the project dependencies.
	Dependencies []string `json:"dependencies"`

	// BaseHint is a hint for base image selection
	BaseHint string `json:"base_hint"`

	LLMClient *llm.Client `json:"-"`
}

// Validate checks if the facts are complete and valid.
func (f Facts) Validate() error {
	var missing []string

	if f.Language == "" {
		missing = append(missing, "language")
	}
	if f.Framework == "" {
		missing = append(missing, "framework")
	}
	if f.BuildTool == "" {
		missing = append(missing, "build_tool")
	}
	if f.BuildCmd == "" {
		missing = append(missing, "build_cmd")
	}
	if f.Artifact == "" {
		missing = append(missing, "artifact")
	}
	if len(f.Ports) == 0 {
		missing = append(missing, "ports")
	}
	if len(f.Env) == 0 {
		missing = append(missing, "env")
	}

	if len(missing) > 0 {
		return fmt.Errorf("missing required facts: %s", strings.Join(missing, ", "))
	}

	// Check build tool specific requirements
	if strings.Contains(f.BuildCmd, "mvn") {
		if !strings.Contains(f.BuildCmd, "-f") {
			// Check both build directory and root
			if !util.FileExists(filepath.Join(f.BuildDir, "pom.xml")) && !util.FileExists("pom.xml") {
				return fmt.Errorf("build cmd uses Maven but no pom.xml found in %s or root", f.BuildDir)
			}
		}
	}

	if strings.Contains(f.BuildCmd, "npm") || strings.Contains(f.BuildCmd, "yarn") {
		if !util.FileExists(filepath.Join(f.BuildDir, "package.json")) && !util.FileExists("package.json") {
			return fmt.Errorf("build cmd uses npm/yarn but no package.json found in %s or root", f.BuildDir)
		}
	}

	if strings.Contains(f.BuildCmd, "pip") || strings.Contains(f.BuildCmd, "poetry") {
		hasRequirements := util.FileExists(filepath.Join(f.BuildDir, "requirements.txt")) || util.FileExists("requirements.txt")
		hasPyProject := util.FileExists(filepath.Join(f.BuildDir, "pyproject.toml")) || util.FileExists("pyproject.toml")
		if !hasRequirements && !hasPyProject {
			return fmt.Errorf("build cmd uses pip/poetry but no requirements.txt or pyproject.toml found in %s or root", f.BuildDir)
		}
	}

	if strings.Contains(f.BuildCmd, "go build") {
		if !util.FileExists(filepath.Join(f.BuildDir, "go.mod")) && !util.FileExists("go.mod") {
			return fmt.Errorf("build cmd uses Go but no go.mod found in %s or root", f.BuildDir)
		}
	}

	return nil
}

// FromJSON parses facts from JSON.
func FromJSON(data interface{}) (Facts, error) {
	var f Facts

	// If data is already a map, marshal it to JSON first
	if m, ok := data.(map[string]interface{}); ok {
		jsonData, err := json.Marshal(m)
		if err != nil {
			return Facts{}, fmt.Errorf("marshal facts map: %w", err)
		}
		data = jsonData
	}

	// Parse JSON bytes
	if jsonData, ok := data.([]byte); ok {
		if err := json.Unmarshal(jsonData, &f); err != nil {
			return Facts{}, fmt.Errorf("parse facts: %w", err)
		}
		return f, nil
	}

	return Facts{}, fmt.Errorf("unsupported facts data type")
}

// ToJSON converts facts to JSON.
func (f Facts) ToJSON() ([]byte, error) {
	return json.MarshalIndent(f, "", "  ")
}

// ToMap converts facts to a map.
func (f Facts) ToMap() map[string]interface{} {
	// Marshal to JSON then unmarshal to map to handle all fields
	data, _ := f.ToJSON()
	var m map[string]interface{}
	_ = json.Unmarshal(data, &m)
	return m
}

// Log writes the facts to the logger.
func (f Facts) Log(logger *slog.Logger) {
	if os.Getenv("DG_DEBUG") != "1" {
		return
	}

	logger.Debug("project facts",
		"language", f.Language,
		"framework", f.Framework,
		"version", f.Version,
		"build_tool", f.BuildTool,
		"build_cmd", f.BuildCmd,
		"build_dir", f.BuildDir,
		"artifact", f.Artifact,
		"ports", f.Ports,
		"env", f.Env,
		"health", f.Health,
		"dependencies", f.Dependencies,
	)
}
