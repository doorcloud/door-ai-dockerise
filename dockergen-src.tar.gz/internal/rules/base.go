package rules

import (
	"context"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"

	"github.com/yourorg/dockergen/internal/facts"
	"github.com/yourorg/dockergen/internal/llm"
	"github.com/yourorg/dockergen/internal/snippet"
)

// Rule defines the interface that all technology-specific rules must implement.
type Rule interface {
	// Detect returns true if this rule should handle the given repository.
	Detect(repo string) bool

	// Snippets extracts relevant code snippets from the repository.
	Snippets(repo string) ([]snippet.T, error)

	// Facts uses the LLM to analyze snippets and extract project facts.
	Facts(ctx context.Context, snips []snippet.T, c *llm.Client) (facts.Facts, error)

	// Dockerfile generates a Dockerfile based on the extracted facts.
	Dockerfile(ctx context.Context, f facts.Facts, c *llm.Client) (string, error)
}

// BaseRule provides common functionality for all rules.
type BaseRule struct {
	logger *slog.Logger
}

// NewBaseRule creates a new BaseRule with the given logger.
func NewBaseRule(logger *slog.Logger) BaseRule {
	return BaseRule{logger: logger}
}

// Log returns the rule's logger.
func (r BaseRule) Log() *slog.Logger {
	return r.logger
}

// DetectSentinelFiles checks if any of the given files exist in the path.
func (r BaseRule) DetectSentinelFiles(path string, files []string) bool {
	for _, file := range files {
		if _, err := os.Stat(filepath.Join(path, file)); err == nil {
			return true
		}
	}
	return false
}

// FindFiles returns all files matching the given glob patterns.
func (r BaseRule) FindFiles(path string, patterns []string) ([]string, error) {
	var matches []string
	for _, pattern := range patterns {
		glob := filepath.Join(path, pattern)
		files, err := filepath.Glob(glob)
		if err != nil {
			return nil, fmt.Errorf("glob %s: %w", glob, err)
		}
		matches = append(matches, files...)
	}
	return matches, nil
}

// RegisteredRules holds all registered rules.
var RegisteredRules []Rule

// Register adds a rule to the registry.
func Register(r Rule) {
	RegisteredRules = append(RegisteredRules, r)
}
