package golang

import (
	"context"
	"fmt"
	"log/slog"
	"os"

	"github.com/yourorg/dockergen/internal/facts"
	"github.com/yourorg/dockergen/internal/llm"
	"github.com/yourorg/dockergen/internal/rules"
	"github.com/yourorg/dockergen/internal/snippet"
)

// Rule implements the Rule interface for Go projects.
type Rule struct {
	rules.BaseRule
}

// NewRule creates a new Go rule.
func NewRule(logger *slog.Logger) *Rule {
	return &Rule{
		BaseRule: rules.NewBaseRule(logger),
	}
}

// Detect returns true if this is a Go project.
func (r *Rule) Detect(path string) bool {
	// Fast: Check for go.mod
	if !r.DetectSentinelFiles(path, []string{"go.mod"}) {
		return false
	}

	// Medium: Check for framework-specific files
	frameworkFiles := []string{
		"main.go",     // Standard Go
		"cmd/**/*.go", // Common Go layout
		"internal/**/*.go",
		"pkg/**/*.go",
	}
	return r.DetectSentinelFiles(path, frameworkFiles)
}

// Snippets extracts relevant code snippets from the repository.
func (r *Rule) Snippets(path string) ([]snippet.T, error) {
	// Look for key files
	patterns := []string{
		"go.mod",
		"go.sum",
		"main.go",
		"cmd/**/*.go",
		"internal/**/*.go",
		"pkg/**/*.go",
		"*.go",
	}

	paths, err := r.FindFiles(path, patterns)
	if err != nil {
		return nil, fmt.Errorf("find files: %w", err)
	}

	// Limit Go files to first 100 lines
	snippets, err := snippet.ReadFilesWithLimit(paths, 100)
	if err != nil {
		return nil, fmt.Errorf("read files: %w", err)
	}

	snippet.Log(r.Log(), snippets)
	return snippets, nil
}

// Facts uses the LLM to analyze snippets and extract project facts.
func (r *Rule) Facts(ctx context.Context, snips []snippet.T, c *llm.Client) (facts.Facts, error) {
	// Convert snippets to strings for the LLM
	var snippetStrs []string
	for _, s := range snips {
		snippetStrs = append(snippetStrs, fmt.Sprintf("=== %s ===\n%s", s.Path, s.Content))
	}

	// Get facts from LLM
	factsMap, err := c.GenerateFacts(ctx, snippetStrs)
	if err != nil {
		return facts.Facts{}, fmt.Errorf("generate facts: %w", err)
	}

	// Convert to Facts struct
	f, err := facts.FromJSON(factsMap)
	if err != nil {
		return facts.Facts{}, fmt.Errorf("parse facts: %w", err)
	}

	f.Log(r.Log())
	return f, nil
}

// Dockerfile generates a Dockerfile based on the extracted facts.
func (r *Rule) Dockerfile(ctx context.Context, f facts.Facts, c *llm.Client) (string, error) {
	// Convert facts to map for LLM
	factsMap := f.ToMap()

	// Generate Dockerfile
	dockerfile, err := c.GenerateDockerfile(ctx, factsMap)
	if err != nil {
		return "", fmt.Errorf("generate dockerfile: %w", err)
	}

	if os.Getenv("DG_DEBUG") == "1" {
		r.Log().Debug("generated dockerfile", "content", dockerfile)
	}

	return dockerfile, nil
}

func init() {
	rules.Register(NewRule(slog.Default()))
}
