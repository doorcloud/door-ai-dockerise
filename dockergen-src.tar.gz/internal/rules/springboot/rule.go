package springboot

import (
	"context"
	"fmt"
	"log/slog"
	"os"
	"regexp"
	"strconv"
	"strings"

	"github.com/yourorg/dockergen/internal/facts"
	"github.com/yourorg/dockergen/internal/llm"
	"github.com/yourorg/dockergen/internal/rules"
	"github.com/yourorg/dockergen/internal/snippet"
	"github.com/yourorg/dockergen/pkg/rule"
	"gopkg.in/yaml.v3"
)

// Rule implements the Rule interface for Spring Boot projects.
type Rule struct {
	rule.BaseRule
	llmClient *llm.Client
	config    *rules.RuleConfig
}

// NewRule creates a new Spring Boot rule.
func NewRule(logger *slog.Logger, llmClient *llm.Client, config *rules.RuleConfig) *Rule {
	return &Rule{
		BaseRule:  rule.NewBaseRule(logger),
		llmClient: llmClient,
		config:    config,
	}
}

// Detect returns true if this is a Spring Boot project.
func (r *Rule) Detect(path string) bool {
	// Check for build files and directories
	if !r.DetectAny(path,
		"pom.xml",
		"build.gradle*",
		"settings.gradle*",
		"mvnw",
		".mvn/**",
		"gradle/**",
	) {
		return false
	}

	// Check for Spring Boot application class
	matches, err := r.FindFiles(path, 2, []string{".git", ".mvn/wrapper"}, "src/main/**Application.*")
	if err != nil {
		r.Log().Error("error finding application class", "error", err)
		return false
	}

	for _, match := range matches {
		content, err := os.ReadFile(match)
		if err != nil {
			continue
		}
		if strings.Contains(string(content), "@SpringBootApplication") {
			return true
		}
	}

	return false
}

// Snippets extracts relevant code snippets from the repository.
func (r *Rule) Snippets(path string) ([]snippet.T, error) {
	var snippets []snippet.T

	// Get build file
	buildFiles, err := r.FindFiles(path, 1, nil, "pom.xml", "build.gradle*")
	if err != nil {
		return nil, err
	}
	if len(buildFiles) > 0 {
		content, err := os.ReadFile(buildFiles[0])
		if err != nil {
			return nil, err
		}
		lines := strings.Split(string(content), "\n")
		if len(lines) > 400 {
			lines = lines[:400]
		}
		snippets = append(snippets, snippet.T{
			Path:    buildFiles[0],
			Content: strings.Join(lines, "\n"),
		})
	}

	// Get application config files
	configFiles, err := r.FindFiles(path, 2, []string{".git", ".mvn/wrapper"},
		"src/main/resources/application*.{yml,yaml,properties}")
	if err != nil {
		return nil, err
	}
	for _, file := range configFiles {
		content, err := os.ReadFile(file)
		if err != nil {
			continue
		}
		lines := strings.Split(string(content), "\n")
		if len(lines) > 200 {
			lines = lines[:200]
		}
		snippets = append(snippets, snippet.T{
			Path:    file,
			Content: strings.Join(lines, "\n"),
		})
	}

	return snippets, nil
}

// Facts analyzes the snippets to extract facts about the project.
func (r *Rule) Facts(ctx context.Context, snips []snippet.T, c *llm.Client) (facts.Facts, error) {
	f := facts.Facts{
		Language:  r.config.Language,
		Framework: r.config.Framework,
		BuildTool: "maven",
		BuildCmd:  r.config.BuildHints["build_cmd"],
		Artifact:  r.config.BuildHints["artifact"],
		Ports:     []int{8080}, // Default port
		Env:       []string{"SPRING_PROFILES_ACTIVE=production"},
		Health:    "/actuator/health",
	}

	// Extract ports from config files
	for _, snip := range snips {
		if strings.HasSuffix(snip.Path, ".yml") || strings.HasSuffix(snip.Path, ".yaml") {
			var config map[string]interface{}
			if err := yaml.Unmarshal([]byte(snip.Content), &config); err != nil {
				continue
			}
			if port, ok := extractPortFromYAML(config, "server.port"); ok {
				f.Ports = []int{port}
				break
			}
		} else if strings.HasSuffix(snip.Path, ".properties") {
			if port, ok := extractPortFromProperties(snip.Content); ok {
				f.Ports = []int{port}
				break
			}
		}
	}

	return f, nil
}

// extractPortFromYAML extracts the port from a YAML config
func extractPortFromYAML(config map[string]interface{}, key string) (int, bool) {
	parts := strings.Split(key, ".")
	var current interface{} = config
	for _, part := range parts {
		if m, ok := current.(map[string]interface{}); ok {
			if val, exists := m[part]; exists {
				current = val
			} else {
				return 0, false
			}
		} else {
			return 0, false
		}
	}
	if port, ok := current.(int); ok {
		return port, true
	}
	return 0, false
}

// extractPortFromProperties extracts the port from a properties file
func extractPortFromProperties(content string) (int, bool) {
	re := regexp.MustCompile(`server\.port\s*=\s*(\d+)`)
	matches := re.FindStringSubmatch(content)
	if len(matches) > 1 {
		if port, err := strconv.Atoi(matches[1]); err == nil {
			return port, true
		}
	}
	return 0, false
}

// Dockerfile generates a Dockerfile for the project.
func (r *Rule) Dockerfile(ctx context.Context, f facts.Facts, c *llm.Client) (string, error) {
	// Convert facts to map for LLM
	factsMap := f.ToMap()

	// Generate Dockerfile
	dockerfile, err := c.GenerateDockerfile(ctx, factsMap)
	if err != nil {
		return "", fmt.Errorf("generate dockerfile: %w", err)
	}

	if os.Getenv("DG_DEBUG") == "1" {
		r.Log().Debug("generated dockerfile", "content", dockerfile)
	}

	return dockerfile, nil
}

// Detect returns a Spring Boot rule if the repository contains Spring Boot files.
func Detect(repo string) (*rules.StackRule, error) {
	// Load rule configs
	configs, err := rules.LoadRuleConfigs("internal/rules/configs")
	if err != nil {
		return nil, fmt.Errorf("load rule configs: %w", err)
	}

	config, ok := configs["springboot"]
	if !ok {
		return nil, fmt.Errorf("springboot config not found")
	}

	// Check if this is a Spring Boot project
	rule := NewRule(slog.Default(), nil, config)
	if !rule.Detect(repo) {
		return nil, nil
	}

	// Create the rule
	return &rules.StackRule{
		Name:          config.Name,
		Signatures:    config.Signatures,
		ManifestGlobs: config.ManifestGlobs,
		CodeGlobs:     config.CodeGlobs,
		MainRegex:     config.MainRegex,
		BuildHints:    config.BuildHints,
	}, nil
}

func init() {
	rules.RegisterDetector(Detect)
}
