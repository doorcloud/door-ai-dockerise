package dockerverify

import (
	"context"
	"io"
	"testing"

	"github.com/docker/docker/api/types"
	"github.com/yourorg/dockergen/internal/facts"
)

type mockDockerClient struct {
	buildCount int
}

func (m *mockDockerClient) ImageList(ctx context.Context, options types.ImageListOptions) ([]types.ImageSummary, error) {
	// Simulate that the image exists
	return []types.ImageSummary{
		{
			ID: "test-image-id",
			RepoTags: []string{
				"dockergen-e2e:test-digest",
			},
		},
	}, nil
}

func (m *mockDockerClient) ImageBuild(ctx context.Context, context io.Reader, options types.ImageBuildOptions) (types.ImageBuildResponse, error) {
	m.buildCount++
	return types.ImageBuildResponse{
		Body: nil,
	}, nil
}

// mockLLMClient implements the LLM client interface for testing
type mockLLMClient struct{}

func (m *mockLLMClient) GenerateDockerfile(ctx context.Context, facts map[string]interface{}) (string, error) {
	return "FROM openjdk:17\nWORKDIR /app\nCOPY . .\nRUN ./mvnw clean package\nCMD [\"java\", \"-jar\", \"target/*.jar\"]", nil
}

func (m *mockLLMClient) FixDockerfile(ctx context.Context, facts map[string]interface{}, dockerfile string, repo string, buildErrLog string, attempt int) (string, error) {
	return dockerfile, nil
}

func (m *mockLLMClient) GenerateFacts(ctx context.Context, snippets []string) (map[string]interface{}, error) {
	return map[string]interface{}{
		"language":   "java",
		"framework":  "spring-boot",
		"version":    "3.0.0",
		"build_tool": "maven",
		"build_cmd":  "./mvnw clean package",
		"artifact":   "target/*.jar",
		"ports":      []int{8080},
		"env":        map[string]string{"SPRING_PROFILES_ACTIVE": "production"},
		"health":     "/actuator/health",
	}, nil
}

func TestVerifyDockerfile_SkipRebuild(t *testing.T) {
	// Create a mock Docker client
	mockClient := &mockDockerClient{}

	// Create test facts
	testFacts := facts.Facts{
		Language:  "java",
		Framework: "spring-boot",
		BuildTool: "maven",
		LLMClient: &mockLLMClient{},
	}

	// Create a temporary directory for the test
	tempDir := t.TempDir()

	// Run the verification with maxAttempts=4
	_, err := VerifyDockerfile(context.Background(), mockClient, tempDir, testFacts, 4)
	if err != nil {
		t.Fatalf("VerifyDockerfile failed: %v", err)
	}

	// Verify that we only built once
	if mockClient.buildCount > 1 {
		t.Errorf("Expected at most 1 build, got %d", mockClient.buildCount)
	}
}
